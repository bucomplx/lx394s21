test = {   'name': 'q2',
    'points': 1,
    'suites': [{'cases': [{'code': ">>> assert build_stack('s4') == ['s4', 'd', 'c']\n", 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
