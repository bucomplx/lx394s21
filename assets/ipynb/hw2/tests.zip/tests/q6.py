test = {   'name': 'q6',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> assert len(neg_filtered[0]) == 343\n', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
