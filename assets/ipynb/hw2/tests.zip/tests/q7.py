test = {   'name': 'q7',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> assert pos_cleaned == [clean_tweet(t, skipwords) for t in pos_tweets]\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
