test = {   'name': 'q2',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> # Try to make this resilient to changes in the world setup;\n'
                                               '>>> assert not False in [whats_on(a) == b for n in range(8) for (a,b) in nltk.bigrams(build_stack("s{}".format(n))) ]\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
